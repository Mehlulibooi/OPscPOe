package com.example.matrixtimetracker

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.example.matrixtimetracker.databinding.ActivityTimeEntryBinding
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase

class TimeEntryActivity : AppCompatActivity() {

    private lateinit var binding: ActivityTimeEntryBinding
    private lateinit var databaseReference: DatabaseReference

    // Create an ActivityResultLauncher for the image picker
    private val pickImageLauncher = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        uri?.let {
            binding.selectedImageView.setImageURI(it)
        }
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityTimeEntryBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Initialize Firebase Database reference
        databaseReference = FirebaseDatabase.getInstance().getReference("Project Information")

        binding.searchButton.setOnClickListener {
            val searchProjectName: String = binding.searchProjectName.text.toString().trim()
            if (searchProjectName.isNotEmpty()) {
                readData(searchProjectName)
            } else {
                Toast.makeText(this, "Please enter the project name", Toast.LENGTH_SHORT).show()
            }
        }

        binding.imagePickerButton.setOnClickListener {
            // Launch the image picker
            pickImageLauncher.launch("image/*")
        }

    }

    private fun readData(projectName: String) {
        // Disable search button to prevent multiple clicks
        binding.searchButton.isEnabled = false

        // Show loading indicator
        binding.loadingIndicator.visibility = View.VISIBLE

        databaseReference.child(projectName).get().addOnSuccessListener {
            if (it.exists()) {
                val projectDate = it.child("projectDate").value
                val projectCategory = it.child("projectCategory").value
                val projectDesc = it.child("projectDesc").value

                Toast.makeText(this, "Results found", Toast.LENGTH_SHORT).show()
                binding.searchProjectName.text.clear()
                binding.readprojectDate.text = projectDate.toString()
                binding.readprojectCategory.text = projectCategory.toString()
                binding.readprojectDesc.text = projectDesc.toString()
            } else {
                Toast.makeText(this, "Project Name does not exist", Toast.LENGTH_SHORT).show()
            }
        }.addOnFailureListener {
            Toast.makeText(this, "Something went wrong", Toast.LENGTH_SHORT).show()
        }.addOnCompleteListener {
            // Re-enable search button and hide loading indicator after the operation
            binding.searchButton.isEnabled = true
            binding.loadingIndicator.visibility = View.GONE
        }
    }
}